# Grocery Store Management System

## Overview

The Grocery Store Management System is a simple web application built using PHP that allows users to manage grocery items. Users can add new items, view the inventory, and check the expiry status of each item. The system utilizes PHP sessions to store item data temporarily.

## Implementation Details

### 1. Data Structure

- **Arrays**: The system uses a session-based array to store grocery items. Each item is represented as an associative array containing the following details:
  - `name`: The name of the grocery item.
  - `type`: The type/category of the grocery item.
  - `price`: The price of the grocery item (ensured to be a positive number).
  - `expiry_date`: The expiry date of the grocery item.

### 2. Functions

- **displayInventory**: This function retrieves the grocery items from the session and displays them in a user-friendly HTML table format. It also checks the expiry status of each item:
  - If the expiry date is today or in the future, the status is displayed as "Valid".
  - If the expiry date is in the past, the status is displayed as "Expired".

### 3. User Interaction

- Users can add new grocery items through a form. The form captures the item name, type, price, and expiry date. The price input is validated to ensure it is a positive number using the `min` attribute in the HTML input field.

### 4. Expiry Date Check

- The expiry date is compared with the current date using PHP's date functions. This ensures that items with today's date as the expiry date are marked as "Valid".

## Assumptions

- The application runs in a session-enabled environment (e.g., XAMPP, WAMP, MAMP).
- Users input valid data for item details (e.g., correct date format, positive price).
- The application does not persist data beyond the session. For a production-level application, a database would be necessary for permanent storage.

## Challenges Faced

- **Session Management**: Managing session data effectively to persist grocery items across different pages was a challenge. Ensuring that the session is started and maintained correctly was crucial.
- **Input Validation**: Ensuring that user inputs are validated both on the client side (HTML) and server side (PHP) to prevent invalid data from being processed.
- **Date Comparison**: Implementing the logic to compare dates correctly and ensuring that the format is consistent across the application.

## Future Enhancements

- Implement a database (e.g., MySQL) to store grocery items permanently.
- Add features for editing and deleting items from the inventory.
- Implement user authentication to manage access to the system.
- Enhance the user interface with more advanced CSS or JavaScript frameworks.

## Conclusion

The Grocery Store Management System demonstrates the practical application of PHP, arrays, and functions to create a functional web application. It provides a foundation for further enhancements and features that can be added to improve usability and functionality.

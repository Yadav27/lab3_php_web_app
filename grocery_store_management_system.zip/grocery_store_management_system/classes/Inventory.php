<?php
class Inventory {
    private $file = '../data/inventory.json'; // Path to the JSON file

    // Method to add a new product to inventory (appends to JSON file)
    public function addProduct($name, $type, $price, $quantity, $expiry_date) {
        $groceryDetails = $this->getItems(); 

        // Create a new product
        $newProduct = [
            'name' => $name,
            'type' => $type,
            'price' => $price,
            'quantity' => $quantity,
            'expiry_date' => $expiry_date
        ];

        // Add the new product to the inventory
        $groceryDetails[] = $newProduct;

        // Save the updated inventory to the JSON file
        $this->saveItems($groceryDetails); // Save updated products back to JSON
    }

    public function updateQuantity($name, $newQuantity) {
        $groceryDetails = $this->getItems();

        // Loop through inventory to find the product and update its quantity
        foreach ($groceryDetails as &$product) {
            if ($product['name'] == $name) {
                $product['quantity'] = $newQuantity; // Update the quantity
                $this->saveItems($groceryDetails); // Save the updated inventory
                return true; // Return true when the update is successful
            }
        }
        return false; // Return false if the product is not found
    }

    // Method to retrieve items from the JSON file
    public function getItems() {
        if (file_exists($this->file)) {
            $jsonData = file_get_contents($this->file);
            return json_decode($jsonData, true) ?? [];
        }
        return []; // Return empty array if file doesn't exist
    }

    // Method to save items back to the JSON file
    private function saveItems($items) {
        file_put_contents($this->file, json_encode($items, JSON_PRETTY_PRINT));
    }

    // Method to display the current inventory in HTML
    public function displayInventory() {
        $items = $this->getItems();
        if (empty($items)) {
            echo "<p>No items in inventory.</p>";
            return;
        }

        echo "<table border='1'>
                <tr>
                    <th>Item Name</th>
                    <th>Item Type</th>
                    <th>Item Price</th>
                    <th>Quantity</th>
                    <th>Expiry Date</th>
                    <th>Status</th>
                </tr>";

        foreach ($items as $item) {
            $expiry_date = $item['expiry_date'];
            $current_date = date("Y-m-d");
            $status = ($expiry_date >= $current_date) ? "Valid" : "Expired";
            echo "<tr>
                    <td>{$item['name']}</td>
                    <td>{$item['type']}</td>
                    <td>\${$item['price']}</td>
                    <td>{$item['quantity']}</td>
                    <td>{$item['expiry_date']}</td>
                    <td>{$status}</td>
                  </tr>";
        }
        echo "</table>";
    }
}
?>

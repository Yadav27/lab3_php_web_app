<?php
class Order {
    private $customerName;
    private $products = [];
    private $totalAmount = 0;

    public function __construct($customerName) {
        $this->customerName = $customerName;
    }

    public function addProduct($name, $quantity, $price) {
        $this->products[] = ['name' => $name, 'quantity' => $quantity, 'price' => $price];
        $this->totalAmount += $quantity * $price;
    }

    public function processOrder($inventory) {
        foreach ($this->products as $product) {
            $inventory->updateQuantity($product['name'], $product['quantity']);
        }
    }

    public function generateSummary() {
        $summary = "Order Summary for " . $this->customerName . "<br>";
        foreach ($this->products as $product) {
            $summary .= "{$product['name']} - {$product['quantity']} x \${$product['price']}<br>";
        }
        $summary .= "Total Amount: \$" . number_format($this->totalAmount, 2) . "<br>";
        return $summary;
    }
}
?>

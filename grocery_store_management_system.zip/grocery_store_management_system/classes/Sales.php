<?php
class Sales {
    private $file = '../data/sales.json'; // External JSON file for sales data

    // Get sales data
    public function getSales() {
        if (file_exists($this->file)) {
            $jsonData = file_get_contents($this->file);
            return json_decode($jsonData, true) ?? [];
        }
        return []; // Return empty array if file doesn't exist
    }

    // Save sales data to JSON
    private function saveSales($sales) {
        file_put_contents($this->file, json_encode($sales, JSON_PRETTY_PRINT));
    }

    // Display sales report
    public function displaySalesReport() {
        $sales = $this->getSales();
        $report = "";
        foreach ($sales as $sale) {
            $report .= "Item: " . $sale['name'] . " | Quantity: " . $sale['quantity'] . " | Total: $" . $sale['total'] . "\n";
        }
        return $report ?: "No sales data available.";
    }

    // Add new sale
    public function addSale($name, $quantity, $price) {
        $sales = $this->getSales();
        $newSale = [
            'name' => $name,
            'quantity' => $quantity,
            'total' => $quantity * $price
        ];
        $sales[] = $newSale;
        $this->saveSales($sales);
    }
}
?>

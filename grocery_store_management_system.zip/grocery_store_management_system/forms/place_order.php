<?php
require_once '../classes/Inventory.php';
require_once '../classes/Order.php';

$inventory = new Inventory();  // Load inventory from JSON file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order = new Order($_POST['customer_name']);
    foreach ($_POST['products'] as $productName) {
        $product = array_filter($inventory->getItems(), function($item) use ($productName) {
            return $item['name'] === $productName;
        });
        $product = reset($product);
        $order->addProduct($product['name'], 1, $product['price']);
    }
    $order->processOrder($inventory);
    echo $order->generateSummary();
    exit();
}

$products = $inventory->getItems(); // Retrieve inventory items from JSON
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Place Order</title>
</head>
<body>
    <h2>Place Order</h2>
    <form action="" method="POST">
        <label for="customer_name">Customer Name:</label>
        <input type="text" name="customer_name" required><br>
        <label>Select Products:</label><br>
        <?php foreach ($products as $product): ?>
            <input type="checkbox" name="products[]" value="<?php echo $product['name']; ?>">
            <?php echo $product['name']; ?> - $<?php echo $product['price']; ?><br>
        <?php endforeach; ?>
        <input type="submit" value="Place Order">
    </form>
</body>
</html>

<?php
require_once '../classes/Inventory.php';

$inventory = new Inventory();
$searchResult = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $searchTerm = $_POST['search_term'];
    $items = $inventory->getItems();
    $searchResult = array_filter($items, function($item) use ($searchTerm) {
        return stripos($item['name'], $searchTerm) !== false;
    });
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Product</title>
</head>
<body>
    <h2>Search Product</h2>
    <form action="" method="post">
        <label for="search_term">Search Term:</label>
        <input type="text" name="search_term" required><br>
        <input type="submit" value="Search">
    </form>

    <?php if ($searchResult): ?>
        <h3>Search Results:</h3>
        <ul>
            <?php foreach ($searchResult as $item): ?>
                <li><?php echo $item['name']; ?> - $<?php echo $item['price']; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</body>
</html>

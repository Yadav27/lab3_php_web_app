<?php
require_once '../classes/Inventory.php';

$inventory = new Inventory();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Update product quantity in the inventory
    $inventory->updateQuantity($_POST['product'], $_POST['quantity']);

    // Redirect to index or show success message
    header('Location: ../public/index.php');
    exit();
}

$products = $inventory->getItems();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Product Quantity</title>
</head>
<body>
    <h2>Update Product Quantity</h2>
    <form action="" method="POST">
        <label for="product">Select Product:</label>
        <select name="product" required>
            <?php foreach ($products as $product): ?>
                <option value="<?php echo $product['name']; ?>"><?php echo $product['name']; ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label for="quantity">New Quantity:</label>
        <input type="number" name="quantity" min="0" required><br><br>

        <input type="submit" value="Update Quantity">
    </form>
</body>
</html>

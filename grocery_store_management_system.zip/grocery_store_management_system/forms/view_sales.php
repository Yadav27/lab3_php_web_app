<?php
require_once '../classes/Sales.php';

$sales = new Sales();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Refresh the report if needed (reads from JSON file)
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Sales Report</title>
</head>
<body>
    <h2>Sales Report</h2>
    <form action="" method="post">
        <textarea readonly rows="10" cols="50"><?php echo $sales->displaySalesReport(); ?></textarea><br>
        <input type="submit" value="Refresh Report">
    </form>
</body>
</html>

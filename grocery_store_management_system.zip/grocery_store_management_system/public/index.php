<?php
require_once '../classes/Inventory.php';

$inventory = new Inventory();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grocery Store Management System</title>
</head>
<body>
    <h1>Grocery Store Management System</h1>

    <nav>
        <ul>
            <li><a href="../forms/add_product.php">Add New Product</a></li>
            <li><a href="../forms/update_quantity.php">Update Product Quantity</a></li>
            <li><a href="../forms/place_order.php">Place Order</a></li>
            <li><a href="../forms/view_sales.php">View Sales Report</a></li>
            <li><a href="../forms/search_product.php">Search Product</a></li>
        </ul>
    </nav>

    <h2>Current Inventory</h2>
    <?php 
    // Display the inventory from the JSON file
    $inventory->displayInventory();
    ?>
</body>
</html>
